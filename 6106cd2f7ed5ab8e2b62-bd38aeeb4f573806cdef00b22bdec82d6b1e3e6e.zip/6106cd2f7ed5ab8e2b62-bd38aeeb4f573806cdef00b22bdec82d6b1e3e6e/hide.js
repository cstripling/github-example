$("#loading").css("visibility", "hidden");

$("#toogle-wms").css("visibility", "hidden");
$("#toogle-tms").css("visibility", "hidden");
$("#toogle-change").css("visibility", "hidden");
$("#toogle-time").css("visibility", "hidden");
$("#toogle-ani").css("visibility", "hidden");
$("#setAnimation").css("visibility", "hidden");
